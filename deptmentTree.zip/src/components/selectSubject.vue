<template>
	<div class="right_li_name ellipsis" :title="item.name">
		{{ item.name }}
	</div>
</template>

<script>
export default {
	props: {
		item: {
			type: Object,
			default: {}
		}
	}
}
</script>

<style></style>
