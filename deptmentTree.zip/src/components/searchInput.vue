<template>
  <div class="search">
    <Input
      prefix="ios-search"
      placeholder="请输入搜索内容"
      v-model="rangeSearchInp"
      @on-enter="showRangeSearch"
    />
    <Button class="_theme_b" type="primary" @click="showRangeSearch"
      >搜索</Button
    >
  </div>
</template>

<script>
export default {
  data() {
    return {
      rangeSearchInp: '',
    };
  },
  methods: {
    showRangeSearch() {},
  },
};
</script>

<style lang="less" scoped>
.search {
  height: 70px;
  padding: 14px 23px;
  border-bottom: 1px solid #ecf1f8;
  display: flex;
  justify-content: flex-start;
  /deep/.ivu-input-wrapper {
    width: 350px;
    margin-right: 20px;
    .ivu-input {
      background-color: #f4f6fa;
      width: 350px;
    }
  }
}
</style>
