<template>
	<div class="selectTree">
		<searchInput></searchInput>
		<div class="content">
			<div class="left">
				<treeConent></treeConent>
			</div>
			<div class="borderCenter"></div>
			<div class="rigth">
				<selectContent :selectData="selectData"></selectContent>
			</div>
		</div>
	</div>
</template>

<script>
import searchInput from '../components/searchInput'
import selectContent from './selectContent'
import treeConent from './treeConent'
export default {
	components: { searchInput, selectContent, treeConent },
	data() {
		return {
			selectData: [
				{
					id: '248',
					name: '三级_随便',
					value: '三级_随便',
					label: '248',
					parentId: '247',
					order: null,
					level: 3,
					children: [],
					nodeId: '248',
					isOpen: false,
					isActive: false,
					isCheck: false,
					checked: true,
					title: '三级_随便',
					showNameKey: '三级_随便',
					nodeKey: 8,
					indeterminate: false,
					parentType: 'subject'
				},
				{
					id: '218',
					name: '三级科目_01',
					value: '三级科目_01',
					label: '218',
					parentId: '216',
					order: null,
					level: 3,
					children: [],
					nodeId: '218',
					isOpen: false,
					isActive: false,
					isCheck: false,
					checked: true,
					title: '三级科目_01',
					showNameKey: '三级科目_01',
					nodeKey: 12,
					indeterminate: false,
					parentType: 'subject'
				},
				{
					id: '219',
					name: '三级科目_02',
					value: '三级科目_02',
					label: '219',
					parentId: '216',
					order: null,
					level: 3,
					children: [],
					nodeId: '219',
					isOpen: false,
					isActive: false,
					isCheck: false,
					checked: true,
					title: '三级科目_02',
					showNameKey: '三级科目_02',
					nodeKey: 13,
					indeterminate: false,
					parentType: 'subject'
				},
				{
					id: '10',
					name: '服务',
					value: '服务',
					label: '10',
					parentId: '216',
					order: null,
					level: 3,
					children: [],
					nodeId: '10',
					isOpen: false,
					isActive: false,
					isCheck: false,
					checked: true,
					title: '服务',
					showNameKey: '服务',
					nodeKey: 14,
					indeterminate: false,
					parentType: 'subject'
				}
			]
		}
	}
}
</script>

<style lang="less" scoped>
.selectTree {
	height: 100%;
}
.content {
	display: flex;
	flex-direction: row;
	height: calc(100% - 190px);
	.left {
		width: 50%;
	}
	.borderCenter {
		border-right: 1px solid #ecf1f8;
	}
	.rigth {
		width: 50%;
	}
}
</style>
