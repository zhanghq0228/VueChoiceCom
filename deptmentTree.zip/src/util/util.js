/**
 * tree 数据转换
 * @param {*} tree tree 待转换的 tree
 * @param {*} map map  键值对映射
 * @param {*} selectData selectData  选择数据list
 * @return {Array}      转换后的 tree
 */
export const convertTree = (tree, map, selectData) => {
	const result = []
	tree.forEach(item => {
		const id = item[map.id]
		const title = item[map.title]
		let children = item[map.children]
		selectData.inc
		children == null ? (children = []) : (children = convertTree(children, map))
		result.push({
			id,
			title,
			expand: false,
			children,
		})
	})
	return result
}
