<template>
	<Drawer class="drawer_range" :width="width" @on-close="$emit('closeHandler')" :title="title" v-model="drawerShow">
		<div class="selectTree">
			<searchInput></searchInput>
			<div class="content">
				<div class="left">
					<treeConent :treeData="treeData" :showCheckBox="showCheckBox" @on-check-change="checkHandler" @on-tree-click="clickHandler"></treeConent>
				</div>
				<div class="borderCenter"></div>
				<div class="rigth">
					<selectContent :selectData="selectData" @del_select_data="delSelectHandler"></selectContent>
				</div>
			</div>
		</div>
		<div class="footer">
			<Button @click="myShow = false">取消</Button>
			<Button @click="submit" type="primary">确定</Button>
		</div>
	</Drawer>
</template>

<script>
import searchInput from './components/searchInput'
import selectContent from './page/selectContent'
import treeConent from './page/treeConent'
import { convertTree } from './util/util'
export default {
	props: {
		// 操作外部显隐函数 必传
		visibleShow: {
			type: Function,
			required: true,
			default: val => val,
		},
		width: {
			type: String,
			default: '610',
		},
		title: {
			type: String,
			default: '',
		},
		show: {
			type: Boolean,
			default: false,
		},
		showCheckBox: {
			type: Boolean,
			default: true,
		},
		// 树需要展示数据 POST_TYPE:岗位 ROLE_TYPE:角色 DEPT_TYPE:部门 COST_TYPE:费用类型 ALL_TYPE:角色岗位部门
		treeType: {
			type: String,
			default: 'COST_TYPE',
		},
		reverSelect: {
			type: Array,
			default: [],
		},
	},
	computed: {
		drawerShow: {
			get() {
				return this.show
			},
			set(val) {
				this.visibleShow(val)
			},
		},
	},
	components: { searchInput, selectContent, treeConent },
	watch: {
		show(val) {
			val ? this.initTree() : ''
		},
		reverSelect(val) {
			this.selectData = val
		},
	},
	data() {
		return {
			selectData: [],
			treeData: [],
		}
	},
	methods: {
		//初始化tree
		async initTree() {
			const params = {
				companyId: sessionStorage.companyId,
				compId: sessionStorage.companyId,
				pageSize: 1000000,
			}
			const coverType = {
				id: this.treeType == 'POST_TYPE' ? 'id' : 'nodeId',
				children: 'children',
				title: this.treeType == 'POST_TYPE' ? 'positionName' : this.treeType == 'DEPT_TYPE' ? 'departName' : 'roleName',
			}

			const getTreeDataMethod = this.$config[this.treeType]
			let { data } = await getTreeDataMethod(params)
			if (data.code !== 10200) {
				this.$$Message.info(data.message)
				return
			}
			const selectIdList = this.selectData.filter(item => item.id)
			console.log(selectIdList, 'selectIdList')
			const response = convertTree(this.treeType == 'ROLE_TYPE' ? data.data.data : data.data.dataTree, coverType, selectIdList)
			console.log(response, 'zheshi')
			this.treeData = response
		},
		// tree 单击
		clickHandler(data) {
			console.log(data, 'tree 单击')
			this.showCheckBox ? '' : this.dupRemove(data)
		},
		// tree 复选框单击
		checkHandler(data) {
			console.log(data, 'tree 复选单击')
			this.selectData = data
		},
		//删除选中
		delSelectHandler(index, item) {
			this.selectData.splice(index, 1)
			console.log(item, 'kanlan')
			item.checked = false
		},
		//选中去重
		dupRemove(data) {
			const selectIndex = this.selectData.findIndex(item => item.id == data.id)
			selectIndex >= 0 ? this.selectData.splice(selectIndex, 1) : this.selectData.push(data)
		},
		//确定
		submit() {
			console.log(JSON.stringify(this.selectData), 'this.selectData')
			this.$emit('submit', this.selectData)
		},
	},
}
</script>

<style lang="less" scoped>
.selectTree {
	height: 100%;
}
.content {
	display: flex;
	flex-direction: row;
	height: calc(100% - 100px);
	.left {
		width: 50%;
		overflow: auto;
	}
	.borderCenter {
		border-right: 1px solid #ecf1f8;
	}
	.rigth {
		width: 50%;
	}
}
.footer {
	position: fixed;
	bottom: 28px;
	width: 600px;
	text-align: right;
	border-top: 1px solid #ecf1f8;
	padding: 28px 0;
	height: 40px;
	/deep/.ivu-btn {
		width: 150px;
		height: 40px;
		background-color: #f4f6fa;
	}
	/deep/.ivu-btn-primary {
		margin-left: 20px;
		color: #fff;
		background: linear-gradient(159deg, #5665b4 0%, #755f90 100%);
	}
}
</style>
